<?php get_header(); ?>
			
<div id="content">

	<div id="inner-content" class="row" data-equalizer>

		<?php get_sidebar(); ?>

		<main id="main" class="large-8 medium-12 columns" role="main" data-equalizer-watch>
		
		    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		    	<?php get_template_part( 'parts/loop', 'single' ); ?>
		    	
		    <?php endwhile; else : ?>
		
		   		<?php get_template_part( 'parts/content', 'missing' ); ?>

		    <?php endif; ?>

		</main> <!-- end #main -->

	</div> <!-- end #inner-content -->

</div> <!-- end #content -->

<?php get_footer(); ?>