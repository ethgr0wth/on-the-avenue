<?php if (!is_front_page()) {
    get_template_part('parts/content', 'promos');
} ?>

<?php get_template_part('parts/content', 'instafeed'); ?>

<footer class="footer" role="contentinfo">

    <div id="footer-top" class="row" data-equalizer data-equalize-on="large">
        <div class="large-4 small-12 columns text-center" data-equalizer-watch>
            <a href="<?php echo home_url(); ?>">
                <?php $logo = im_theme['logo'];
                if ($logo) { ?>
                    <img id="logo" src="<?php echo $logo ?>" alt="<?php bloginfo('name'); ?>"  /> 
                <?php } else { ?> <?php bloginfo('name'); } ?>
            </a>
        </div>
        <div class="large-3 small-12 columns" data-equalizer-watch>
            <?php dynamic_sidebar('footer1'); ?>
        </div>
        <div class="large-2 small-12 columns" data-equalizer-watch>
            <?php dynamic_sidebar('footer2'); ?>
        </div>
        <div class="large-3 small-12 columns last" data-equalizer-watch>
            <a href="https://www.aveda.com/salon/mintontheavenue" target="_blank">
                <img width="133" id="aveda" src="<?php echo get_template_directory_uri(); ?>/assets/images/aveda.png" alt="Aveda" />
            </a>
        </div>
    </div>

    <div id="footer-bottom" class="row fluid">
        <div class="large-12 medium-12 columns text-center">
            <p class="source-org copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. 
            <a href="<?php bloginfo('url'); ?>/privacy-policy">Privacy Policy / Terms &amp; Conditions</a><br/>
            Made with <i class="fa fa-heart" aria-hidden="true"></i> by <a target="_blank" href="https://imaginalmarketing.com">Imaginal Marketing Group</a></p>
        </div>
    </div> <!-- end #inner-footer -->

</footer> <!-- end .footer -->

</div>  <!-- end .main-content -->
</div> <!-- end .off-canvas-wrapper -->

<?php wp_footer(); ?> <!-- WordPress footer hook -->

</body>
</html> <!-- end page -->
