<?php get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<!-- You like promo boxes or what? -->	
		 <?php if (get_field('show_promo_boxes')) {  get_template_part( 'parts/content', 'promos' ); } ?>

		 <!-- This is an additional banner area that can be used for logos, accolades, etc. -->
	   <?php if (get_field('show_banner_area')) { ?>
	    <section id="homeBanner" style="background-image: url('<?php the_field('banner_background_image'); ?>'); background-attachment:<?php the_field('banner_background_attachment'); ?>">
	    	<?php the_field('banner_content'); ?>
	    </section>

	    <?php  } ?>

	<?php endwhile; endif; ?>
	<div id="blogfeed" class="row homeBlog" role="main" data-equalizer data-equalize-on="medium">
		<?php 
		  $args = array(
		        'posts_per_page' => '2',
		        );
		    query_posts($args); ?>
		    <?php if (have_posts()) : while (have_posts()) : the_post(); 
		    $id = get_the_ID();
		    ?>
            <div id="post_<?php echo $id; ?>" class="medium-6 columns" data-equalizer-watch>
                <h4><?php the_title(); ?></h4>
                <?php the_excerpt(); ?>
                <a class="button" href="<?php the_permalink(); ?>">Read More</a>
             </div>
		<?php endwhile; else : endif; wp_reset_query(); ?>
    </div>

<?php get_footer(); ?>