
<?php function rudr_instagram_api_curl_connect( $api_url ){
		$connection_c = curl_init(); // initializing
		curl_setopt( $connection_c, CURLOPT_URL, $api_url ); // API URL to connect
		curl_setopt( $connection_c, CURLOPT_RETURNTRANSFER, 1 ); // return the result, do not print
		curl_setopt( $connection_c, CURLOPT_TIMEOUT, 20 );
		$json_return = curl_exec( $connection_c ); // connect and get json data
		curl_close( $connection_c ); // close connection
		return json_decode( $json_return ); // decode and return
	}
	$access_token = '384804025.1677ed0.a2c93993b12242d7b710e0e54609fdeb';
	$return = rudr_instagram_api_curl_connect("https://api.instagram.com/v1/users/self/media/recent/?access_token=" . $access_token);
?>

<div id="instafeed" class="row fluid">
	<div class="medium-10 medium-offset-1 end columns">
        <a class="button" href="https://www.instagram.com/explore/locations/2945414/bangz-park-avenue-salon/" target="_blank">Follow us on Instagram</a>
		<div id="beginfeed" class="row fluid small-2-up medium-4-up large-5-up">
			<?php
			$limit = 20; //limit
			$o = 0; //offset
			$i = 0; //counter
			foreach ($return->data as $post) {
		   		if ($i++ < $o) continue;
		    	if ($i > $o + $limit) break;
				echo '<div class="column column-block"><a target="_blank" href="' . $post->link . '" style="background-image:url(\'' . $post->images->standard_resolution->url . '\');"></a></div>';
			} ?>
		</div>
	</div>
</div>