<?php 
  $args = array(
        'post_type' => 'promo_btn',
        'posts_per_page' => '1',
        'orderby' => 'menu_order',
        'order' => 'ASC'
        );
    query_posts($args); ?>



    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="promoWrapper" class="row" data-equalizer="promo" data-equalize-on="large">
    <div id="left_promo" class="column medium-3 hide-for-medium-only">
        <div class="promo_inner" data-equalizer-watch="promo">
            <div class="promo_img_holder">
                <img src="<?php the_field('promo_image'); ?>" alt="Promo" />
                <a target="_blank" href="<?php the_field('promo_cta'); ?>" class="promo_link <?php the_field('promo_class'); ?>"></a>
                <div class="mask"><a class="<?php the_field('promo_class'); ?>" target="_blank" href="<?php the_field('promo_cta'); ?>"><?php the_field('promo_text'); ?></a></div>
            </div>
        </div>
    </div>
    <div id="mid_promo1" class="column medium-3" data-equalizer="mobile">
        <!-- <div class="column small-6" data-equalizer-watch="promo" data-equalizer-watch="mobile">
            <img class="center-left-img" src="https://mintontheavenue.com/wp-content/uploads/2021/03/Promo3.jpg" alt="Aveda" />
        </div> -->
        <div class="promo_inner" data-equalizer-watch="promo" data-equalizer-watch="mobile">
            <div class="promo_img_holder">
                <img src="<?php the_field('promo_image_center'); ?>" alt="Promo" />
                <a href="<?php the_field('promo_link_center'); ?>" class="promo_link" target="_blank"></a>
                <div class="mask"><a href="<?php the_field('promo_link_center'); ?>" target="_blank"><?php the_field('promo_text_center'); ?></a></div>
                <!-- <div class="promo_text_holder">
                    <div class="promo_text">
                        <p><a href="<?php the_field('promo_link_center'); ?>"><?php the_field('promo_text_center'); ?></a></p>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
    <div id="mid_promo2" class="column medium-3" data-equalizer="mobile">
        <div class="promo_inner" data-equalizer-watch="promo" data-equalizer-watch="mobile">
            <div class="promo_img_holder">
                <img src="<?php the_field('promo_image_center_2'); ?>" alt="Promo" />
                <a href="<?php the_field('promo_link_center_2'); ?>" class="promo_link"></a>
                <div class="mask"><a href="<?php the_field('promo_link_center_2'); ?>"><?php the_field('promo_text_center_2'); ?></a></div>
            </div>
        </div>
    </div>
    <div id="left_promo" class="column medium-6 show-for-medium-only">
        <div class="promo_inner" data-equalizer-watch="promo">
            <div class="promo_img_holder">
                <img src="<?php the_field('promo_image'); ?>" alt="Promo" />
                <a target="_blank" href="<?php the_field('promo_cta'); ?>" class="promo_link"></a>
                <div class="mask"><a target="_blank" href="<?php the_field('promo_cta'); ?>"><?php the_field('promo_text'); ?></a></div>
            </div>
        </div>
    </div>
    <div id="right_promo" class="column medium-6 large-3">
        <div class="promo_inner" data-equalizer-watch="promo">
            <div class="promo_img_holder">
                <img class="show-for-medium" src="<?php the_field('promo_image_right'); ?>" alt="Promo" />
                <img class="hide-for-medium" src="<?php the_field('promo_image_right_mobile'); ?>" alt="Promo" />
                <a href="<?php the_field('promo_link_right'); ?>" class="promo_link"></a>
                <div class="mask"><a href="<?php the_field('promo_link_right'); ?>"><?php the_field('promo_text_right'); ?></a></div>
            </div>
        </div>
    </div>
</div>
<style>
#left_promo, #mid_promo1, #mid_promo2, #right_promo{width:25% !important;padding:0px;}
#left_promo .promo_inner, #mid_promo1 .promo_inner, #mid_promo2 .promo_inner, #right_promo .promo_inner{padding-left: 5px;
padding-right: 5px; margin-left:0px !important; margin-right:0px !important;}
@media screen and (max-width:767px) {
	#left_promo, #mid_promo1, #mid_promo2, #right_promo{width:100% !important;margin-top:10px; margin-bottom:10px;}
}
</style>
<?php endwhile; else : endif; wp_reset_query(); ?>