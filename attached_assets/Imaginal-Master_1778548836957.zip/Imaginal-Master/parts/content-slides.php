<?php 
  $args = array(
        'post_type' => 'hp_slides',
        'posts_per_page' => '-1',
        'orderby' => 'menu_order',
        'order' => 'ASC'
        );
    query_posts($args); ?>



    <?php if (have_posts()) : while (have_posts()) : the_post(); 
    $id = get_the_ID();
    $type = get_field('slide_type');
    ?>
    
        <?php if ( $type == 'text' ) : ?>
        <!-- Text Slide -->
                <div id="slide_<?php echo $id; ?>" class="slide" data-cycle-fx="fade" data-cycle-timeout=<?php if( get_field('slide_timeout') ): ?><?php the_field('slide_timeout'); else : echo '7000'; endif; ?>>
                     <div class="background show-for-medium" style=" background-image: url(<?php the_field('slide_background_image'); ?>);"></div><div class="background hide-for-medium" style=" background-image: url(<?php if(get_field('background_image_mobile')) :  the_field('background_image_mobile'); else : the_field('slide_background_image'); endif; ?>);">
                     </div><!-- /#backgrounds-->
                     
                     <?php if( get_field('slide_link') ): ?><a class="slide_link" href="<?php the_field('slide_link'); ?>"><?php endif; ?>
                    <?php if( get_field('slide_link') ): ?></a><?php endif; ?>
                    <div class="slidetext <?php the_field('slide_content_position'); ?>_position">
                        <div class="slidetext_inner">
                            <?php the_field('slide_text'); ?>
                        </div>
                    </div>
                 </div><!-- /.slide-->    
                     
        <?php elseif ( $type == 'graphic' ) : ?> 
        
            <?php $image = get_field('slide_graphic'); ?>
        <!-- Graphic Slide -->
                <div id="slide_<?php echo $id; ?>" class="slide" data-cycle-fx="fade" data-cycle-timeout=<?php if( get_field('slide_timeout') ): ?><?php the_field('slide_timeout'); else : echo '7000'; endif; ?>>
                     <div class="background show-for-medium" style=" background-image: url(<?php the_field('slide_background_image'); ?>);"></div><div class="background hide-for-medium" style=" background-image: url(<?php if(get_field('background_image_mobile')) :  the_field('background_image_mobile'); else : the_field('slide_background_image'); endif; ?>);">
                     </div><!-- /#backgrounds-->
                     
                     <?php if( get_field('slide_link') ): ?><a class="slide_link" href="<?php the_field('slide_link'); ?>"><?php endif; ?>
                    <?php if( get_field('slide_link') ): ?></a><?php endif; ?>
                    <div class="slidegraphic <?php the_field('slide_content_position'); ?>_position">
                        <div class="slidegraphic_inner">
                            <?php if( get_field('slide_link') ): ?><a href="<?php the_field('slide_link'); ?>"><?php endif; ?><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" border="0" /><?php if( get_field('slide_link') ): ?></a><?php endif; ?>
                        </div>
                    </div>
                 </div><!-- /.slide-->
                    
        <?php endif; ?>
    <?php endwhile; else : endif; wp_reset_query(); ?>