<!doctype html>
<html class="no-js" <?php language_attributes(); ?>>

<head>
	<meta charset="utf-8">
	<!-- Force IE to use the latest rendering engine available -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- Mobile Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta class="foundation-mq">
	

	<!-- If Site Icon isn't set in customizer -->
	<?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) { ?>
	<!-- Icons & Favicons -->
	<link rel="icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">
	<link href="<?php echo get_template_directory_uri(); ?>/assets/images/apple-icon-touch.png" rel="apple-touch-icon"/>
	<!--[if IE]>
				<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
			<![endif]-->
	<meta name="msapplication-TileColor" content="#f01d4f">
	<meta name="msapplication-TileImage" content="<?php echo get_template_directory_uri(); ?>/assets/images/win8-tile-icon.png">
	<meta name="theme-color" content="#121212">
	<?php } ?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	<link type="text/css" rel="stylesheet" href="//www.demandforce.com/widget/css/widget.css"/>
	<?php wp_head(); ?>
	<!-- FontAwesome -->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	
	
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo im_theme['google-analytics-id']; ?>"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', '<?php echo im_theme['google-analytics-id']; ?>');
	</script>


	
	<?php if(get_field('custom_css')): echo '<style>'; the_field('custom_css'); echo '</style>'; endif;?>
</head>


<body <?php body_class(); ?>>


	<div class="off-canvas-wrapper">

		<?php get_template_part( 'parts/content', 'offcanvas' ); ?>

		<div class="off-canvas-content" data-off-canvas-content>


			<header class="header" role="banner">

				<!-- This navs will be applied to the topbar, above all content 
							  To see additional nav styles, visit the /parts directory -->
				<?php get_template_part( 'parts/nav', 'offcanvas-topbar' ); ?>


				<?php // Homepage
						if(is_front_page()){ ?>
				<div id="heroimage">

					<div id="slides" class="cycle-slideshow" data-cycle-speed="600" data-cycle-slides=".slide" data-pause-on-hover="true">

						<?php get_template_part( 'parts/content', 'slides' ); ?>

						<div class="cycle-pager"></div>
					</div>
					<!-- /#slides-->

				</div>
				<!-- /#heroimage-->
				<?php } ?>
				<?php // Interior
						if(!is_front_page()){
						// featured image
						$getimage = get_field('page_title_image');
						if (is_home() || is_singular('post') || is_search() || is_archive()) {
							$feat_image = get_stylesheet_directory_uri().'/assets/images/interior-header.jpg';
						} elseif ($getimage) {
							$feat_image = $getimage;
						} else {
							$feat_image = get_stylesheet_directory_uri().'/assets/images/interior-header.jpg';
						}
						// header alignment
						$getalign = get_field('header_align');
						if ($getalign != null){
							$align = ' '.get_field('header_align');
						} else { $align = ''; }
					?>
				<div id="headerimage" <?php echo 'class="'.$align. '" style="background-image:url(\''.$feat_image.'\');"'; ?>>
				</div>
				<?php } ?>

			</header>
			<!-- end .header -->