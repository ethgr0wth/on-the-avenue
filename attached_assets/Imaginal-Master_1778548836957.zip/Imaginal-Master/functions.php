<?php
// Theme support options
require_once(get_template_directory().'/assets/functions/theme-support.php'); 

// WP Head and other cleanup functions
require_once(get_template_directory().'/assets/functions/cleanup.php'); 

// Register scripts and stylesheets
require_once(get_template_directory().'/assets/functions/enqueue-scripts.php'); 

// Register custom menus and menu walkers
require_once(get_template_directory().'/assets/functions/menu.php'); 

// Register sidebars/widget areas
require_once(get_template_directory().'/assets/functions/sidebar.php'); 

// Makes WordPress comments suck less
require_once(get_template_directory().'/assets/functions/comments.php'); 

// Replace 'older/newer' post links with numbered navigation
require_once(get_template_directory().'/assets/functions/page-navi.php'); 

// Adds support for multiple languages
require_once(get_template_directory().'/assets/translation/translation.php'); 

// Remove 4.2 Emoji Support
require_once(get_template_directory().'/assets/functions/disable-emoji.php'); 

// Adds site styles to the WordPress editor
//require_once(get_template_directory().'/assets/functions/editor-styles.php'); 

// Related post function - no need to rely on plugins
// require_once(get_template_directory().'/assets/functions/related-posts.php'); 

// Use this as a template for custom post types
require_once(get_template_directory().'/assets/functions/custom-post-type.php');

// Customize the WordPress login menu
// require_once(get_template_directory().'/assets/functions/login.php'); 

// Customize the WordPress admin
// require_once(get_template_directory().'/assets/functions/admin.php'); 

// Imaginal Theme Options
require_once(get_template_directory().'/assets/functions/theme-options.php');

// Filter wp_nav_menu() to add additional links and other output
function new_nav_menu_items($items) {
    $homelink = '<li class="phone"><a class="show-for-large" href="'.get_site_url().'/contact"><i class="fa fa-phone" aria-hidden="true"></i><span class="show-for-small-only">407.645.2264</span></a><a class="hide-for-large" href="tel:+14076452264"><i class="fa fa-phone" aria-hidden="true"></i><span class="show-for-small-only">407.645.2264</span></a></li>';
    // add the home link to the end of the menu
    $items = $items . $homelink;
    return $items;
}
add_filter( 'wp_nav_menu_primary-right_items', 'new_nav_menu_items' );

// Enqueue theme stylesheet
wp_enqueue_style( 'style', get_template_directory_uri() . '/style.css');

// Enqueue services script
function add_services_script() {
    wp_enqueue_script( 'services-handler', get_template_directory_uri() . '/assets/js/scripts/services.js', array('jquery'), null, true );
}
add_action( 'wp_enqueue_scripts', 'add_services_script' );

// Enqueue popup script
function enqueue_popup_script() {
    wp_enqueue_script(
        'popup-script', // Handle
        get_template_directory_uri() . '/js/popup.js', // Path to the JS file
        array('jquery'), // Dependencies (jQuery in this case)
        null, // Version (optional)
        true // Load in footer
    );
}
add_action('wp_enqueue_scripts', 'enqueue_popup_script');